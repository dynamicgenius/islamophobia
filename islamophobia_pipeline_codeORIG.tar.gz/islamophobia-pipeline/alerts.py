#!/usr/bin/env python3
"""
Islamophobia Pipeline — Alert Module
Check the DB for high-relevance items and output structured alerts.
Used by the cron job to detect breaking stories.
"""

import os
import sys
import json
import sqlite3
import subprocess
from pathlib import Path

import pandas as pd
from datetime import datetime, timezone
from typing import List, Dict, Optional

DB_PATH = os.getenv('PIPELINE_DB', 'output/islamophobia_pipeline.sqlite3')
BREAKING_THRESHOLD = 0.5  # Items >= this are "high relevance"
INCIDENT_THRESHOLD = 0.3  # Items >= this are "incident relevant"
BREAKING_KEYWORDS = [
    'attack', 'stabbing', 'stabbed', 'fire', 'arson', 'vandalism', 'bomb',
    'threat', 'assault', 'killed', 'murder', 'death', 'cemetery',
    'lockdown', 'security', 'emergency', 'court', 'guilty', 'sentenced',
    'jailed', 'arrest', 'prosecution', 'cps', 'police investigate',
    'mosque attack', 'hijab attack', 'hate crime',
]


def load_alerts(threshold: float = BREAKING_THRESHOLD, limit: int = 15) -> List[Dict]:
    """Load high-relevance items from the pipeline database."""
    if not os.path.exists(DB_PATH):
        return []

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""
        SELECT source, title, url, relevance, published_at, fetched_at
        FROM sources
        WHERE relevance >= ?
        ORDER BY relevance DESC, fetched_at DESC
        LIMIT ?
    """, (threshold, limit))
    rows = cur.fetchall()
    conn.close()

    return [
        {
            'source': r[0],
            'title': r[1],
            'url': r[2],
            'relevance': r[3],
            'published_at': r[4] or r[5],
        }
        for r in rows
    ]


def check_breaking(items: List[Dict]) -> List[Dict]:
    """Check if any alerts are 'breaking' — urgent stories requiring immediate notification."""
    breaking = []
    for item in items:
        title_lower = (item['title'] or '').lower()
        if any(kw in title_lower for kw in BREAKING_KEYWORDS):
            breaking.append(item)
    return breaking


def classify_severity(item: Dict) -> str:
    """Classify severity level for an alert item."""
    title = (item['title'] or '').lower()
    score = item.get('relevance', 0)

    if score >= 0.8 and any(k in title for k in ['attack', 'stab', 'fire', 'killed', 'cemetery', 'bomb']):
        return 'CRITICAL'
    elif score >= 0.7:
        return 'HIGH'
    elif score >= 0.5:
        return 'MEDIUM'
    return 'LOW'


def format_alert(items: List[Dict], breaking_only: bool = False) -> str:
    """Format alerts for human-readable output."""
    if not items:
        return "No high-relevance items found."

    if breaking_only:
        breaking = check_breaking(items)
        if not breaking:
            return "No breaking stories detected."

        lines = ["🚨 **BREAKING ISLAMOPHOBIA ALERTS**\n"]
        for item in breaking:
            severity = classify_severity(item)
            emoji = {'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡'}.get(severity, '⚪')
            lines.append(f"{emoji} [{severity}] {item['title'][:100]}")
            lines.append(f"   Source: {item['source']} | Score: {item['relevance']:.2f}")
            lines.append(f"   {item['url']}")
        return '\n'.join(lines)

    # Full report
    lines = ["📋 **Islamophobia Pipeline — Alert Report**\n"]
    breaking = check_breaking(items)
    if breaking:
        lines.append(f"🚨 Breaking stories: {len(breaking)}\n")

    for item in items:
        severity = classify_severity(item)
        emoji = {'CRITICAL': '🔴', 'HIGH': '🟠', 'MEDIUM': '🟡', 'LOW': '⚪'}.get(severity, '⚪')
        stars = '*' * max(1, int(item['relevance'] * 10))
        is_breaking = '🚨' if item in breaking else ''
        lines.append(f"{emoji} {is_breaking} [{item['relevance']:.2f} {stars}] {item['source']}")
        lines.append(f"   {item['title'][:100]}")
        lines.append(f"   {item['url']}")

    return '\n'.join(lines)


def send_email_alert(breaking: List[Dict]):
    """Send email alert for breaking stories using local msmtp."""
    if not breaking:
        return

    subject = f"Islamophobia BREAKING: {breaking[0]['title'][:60]}"

    body_lines = [
        "Islamophobia Pipeline — Breaking Alert",
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}",
        "",
    ]
    for item in breaking[:5]:
        severity = classify_severity(item)
        body_lines.append(f"[{severity}] {item['source']}")
        body_lines.append(f"  {item['title']}")
        body_lines.append(f"  {item['url']}")
        body_lines.append(f"  Relevance: {item['relevance']:.2f}")
        body_lines.append("")

    body = '\n'.join(body_lines)
    msg = f"Subject: {subject}\nTo: ibbiy@icloud.com\nContent-Type: text/plain; charset=utf-8\n\n{body}"

    try:
        proc = subprocess.run(
            ['msmtp', 'ibbiy@icloud.com'],
            input=msg.encode('utf-8'),
            capture_output=True,
            timeout=15,
        )
        if proc.returncode == 0:
            return True, f"Emailed {len(breaking)} breaking alerts to ibbiy@icloud.com"
        else:
            return False, f"msmtp error: {proc.stderr.decode()[:200]}"
    except Exception as e:
        return False, f"Email failed: {e}"


def main():
    global DB_PATH
    import argparse
    parser = argparse.ArgumentParser(description='Islamophobia Pipeline Alert Module')
    parser.add_argument('--breaking-only', action='store_true', help='Show breaking stories only')
    parser.add_argument('--email', action='store_true', help='Email breaking alerts')
    parser.add_argument('--json', action='store_true', help='Output as JSON')
    parser.add_argument('--threshold', type=float, default=BREAKING_THRESHOLD)
    parser.add_argument('--db', type=str, default=DB_PATH)
    args = parser.parse_args()

    if args.db != DB_PATH:
        DB_PATH = args.db

    items = load_alerts(threshold=args.threshold)
    breaking = check_breaking(items)

    if args.json:
        output = {
            'alerts': items,
            'breaking': breaking,
            'count': len(items),
            'breaking_count': len(breaking),
        }
        print(json.dumps(output, indent=2, ensure_ascii=False))
        return

    if args.email and breaking:
        success, msg = send_email_alert(breaking)
        print(msg)

    print(format_alert(items, breaking_only=args.breaking_only))


# ── Prediction-based alerting (Ibby's version) ──────────────────
PREDICTION_THRESHOLD = 0.7


def load_predictions(path='output/predictions.csv'):
    return pd.read_csv(path)


def build_prediction_alerts(pred_df, threshold=PREDICTION_THRESHOLD):
    """Check if model predictions exceed threshold."""
    if pred_df.empty or 'prediction' not in pred_df.columns:
        return []
    alerts = []
    for _, row in pred_df.iterrows():
        p = float(row['prediction'])
        if p >= threshold:
            alerts.append({
                'level': 'high',
                'horizon': row.get('horizon', 'unknown'),
                'prediction': p,
                'message': f'Predicted incident spike for {row.get("horizon", "unknown")} is {p:.3f}, above threshold {threshold:.2f}.'
            })
    return alerts


def save_prediction_alerts(alerts, path='output/predictions_alerts.json'):
    Path(path).write_text(json.dumps(alerts, indent=2), encoding='utf-8')
    return path


def prediction_alert_main(pred_path='output/predictions.csv',
                           out_path='output/predictions_alerts.json',
                           threshold=PREDICTION_THRESHOLD):
    try:
        pred_df = load_predictions(pred_path)
        alerts = build_prediction_alerts(pred_df, threshold=threshold)
        save_prediction_alerts(alerts, out_path)
        return {'alerts': len(alerts), 'output': out_path}
    except Exception as e:
        return {'alerts': 0, 'error': str(e)}


# ── Merge into main CLI ──────────────────────────────────────────
if __name__ == '__main__':
    main()
